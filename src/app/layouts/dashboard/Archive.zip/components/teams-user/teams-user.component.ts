import { Component } from '@angular/core';

@Component({
  selector: 'app-teams-user',
  templateUrl: './teams-user.component.html',
  styleUrls: ['./teams-user.component.scss']
})
export class TeamsUserComponent {

}
