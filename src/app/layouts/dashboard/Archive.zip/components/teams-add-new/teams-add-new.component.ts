import { Component } from '@angular/core';

@Component({
  selector: 'app-teams-add-new',
  templateUrl: './teams-add-new.component.html',
  styleUrls: ['./teams-add-new.component.scss']
})
export class TeamsAddNewComponent {

}
